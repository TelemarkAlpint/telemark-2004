<!DOCTYPE HTML PUBLIC "-//SoftQuad Software//DTD HoTMetaL PRO 6.0::19990601::extensions to HTML 4.0//EN" "hmpro6.dtd">
<HTML>
  <HEAD>
	 <TITLE>NTNUI Telemark</TITLE>
	 <LINK REL="stylesheet" HREF="../style.css" TYPE="text/css">
  </HEAD>
  <BODY>

  <form method="POST" action="index.php">
  	<p><b>Navn:</b><br>
	  	<input type="text" name="navn" size="20"></p>
	<p><b>E-post:</b><br>
		<input type="text" name="epost" size="20"></p>
	<p><b>Annet:</b><br>
	  	<input type="text" name="annet" size="20"></p>
	<p><b>Passord*:</b> (f.eks f�dselsdato)<br>
	  	<input type="password" name="passord" size="20"></p>
  	<p><input type="submit" value="Meld p�" name="B1"></p>
  </form>

<?php
class input {
	var $allLines;
	var $allenavn;
	var $alleepost;
	var $alleannet;
	var $allepassord;
	function data($inData){
		$this.$allLines = $inData;
		$j = count($linjer)-1;
		for($i = 0; $i < $j; $i++){
			$linje = split("#", $linjer[$i]);
			$allenavn[$i] = $linje[0];
			$alleepost[$i] = $linje[1];
			$alleannet[$i] = $linje[2];
			$allepassord[$i] = $linje[3];
		}
	}
	#sjekker om navnet finnes fra f�r
}

#definerer variable
	global $linjeskift = chr(13);
	global $filename = "data.txt";
#leser fila
	$fp = fopen($filename, "r");
	$gammelData = fread($fp, filesize($filename));
	fclose($fp);

#oppretter inputklasse
	$linjer = split(".:::.", $gammelData);
	$pameldte = new input($linjer);
	

#henter inndata og skriver til fil
	if (	$navn != "" &&
		$epost != "" &&
		$passord != ""){
		$nyData = "$navn	#$epost	#$annet	#$passord#.:::.$linjeskift";

		#skriver til  fil
		$New = "$nyData$gammelData";
		$fp = fopen( $filename,"w+");
		fwrite($fp, $New, filesize($filename)+3000);
		fclose($fp);
	}
	else{
		$nyData = "";
		if (	$navn != "" ||
			$epost != "" ||
			$passord != ""){
			print "<p><font color=red>";
			if ($navn == "") print "Du har ikke tastet <i>navn</i><br>";
			if ($epost == "") print "Du har ikke fylt inn <i>e-post</i><br>";
			if ($passord == "") print "Du har ikke fylt inn <i>passord</i><br>";
			print "Ingen data er registrert. Pr�v igjen</font></p>";
		}
	}

?>
<hr>
<p><b>Hittil p�meldte</b></p>
<table border=0.1 cellpadding=0 bordercolor=#524545 cellspacing=0 width=100%>
  <tr>
    <td width><b>Nr</b></td>
    <td width><b>Navn</b></td>
    <td width><b>E-post</b></td>
    <td width><b>Annet</b></td>
  </tr>
<?php
#oppretter array
	$registrertData = "$nyData$gammelData";
	$linjer = split(".:::.$linjeskift", $registrertData);
	$j = count($linjer)-1;
	for($i = 0; $i<$j; $i++){
		$linje = split("#", $linjer[$i]);
		$allenavn[$i] = $linje[0];
		$alleepost[$i] = $linje[1];
		$alleannet[$i] = $linje[2];
		$allepassord[$i] = $linje[3];
		$tall = $i+1;
		print "<tr><td>$tall</td><td>$allenavn[$i]</td><td>$alleepost[$i]</td><td>$alleannet[$i]</td></tr>$linjeskift";
	}
?>
</table>
<p>* passordet er ikke kryptert og kan leses direkte av p�meldingsansvarlig. Det brukes kun ved avmelding. Bruk f.eks f�dselsdato</p>
</BODY>
</HTML>