<HTML>
  <HEAD>
	 <TITLE>NTNUI Telemark</TITLE>
	 <LINK REL="stylesheet" HREF="../style.css" TYPE="text/css">
  </HEAD>
  <BODY>

  <form method="POST" action="index.php">
  	<p><b>Navn:</b><br>
	  	<input type="text" name="navn" size="20"></p>
	<p><b>E-post:</b><br>
		<input type="text" name="epost" size="20"></p>
	<p><b>Annet:</b><br>
	  	<input type="text" name="annet" size="20"></p>
	<p><b>Passord*:</b> (f.eks f�dselsdato)<br>
	  	<input type="password" name="passord" size="20"></p>
  	<p><input type="submit" value="Meld p�" name="B1"></p>
  </form>
<?php
class test {
    function test() {
        print 'OK';
    }
}
$test = new test();
?> 







#definerer variable
	global $navn;
	global $epost;
	global $annet;
	global $passord;
#leser inn fra fila
	$fp = fopen($filename, "r");
	$gammelData = fread($fp, filesize($filename));
	fclose($fp);

#oppretter inputklasse
	$linjer = split(".:::.", $gammelData);
	$pameldte = new Inputt($linjer);
	$pameldte->skrivUt();
	#print $pameldte->finnes($navn);
	
	
	
	
	
	
	
	
	
class Inputt {
	private $allLines;
	private $alleNavn;
	private $alleEpost;
	private $alleAnnet;
	private $allePassord;
	private $NumberOfLines;
	function data($inData){
		$this->allLines = $inData;
		$this->numberOfLines = count($linjer);
		for($i = 0; $i < $this->numberOfLines; $i++){
			$linje = split("#", $linjer[$i]);
			$alleNavn[$i] = $linje[0];
			$alleEpost[$i] = $linje[1];
			$alleAnnet[$i] = $linje[2];
			$allePassord[$i] = $linje[3];
		}
	}
	function skrivUt(){
		for($i = 0; $i < $numberOfLines; $i++){
			$tall = $i+1;
			echo("<tr><td>$tall</td><td>$this->alleNavn[$i]</td><td>$this->alleEpost[$i]</td><td>$this->alleAnnet[$i]</td></tr>\n");
		}
	}
	
}	