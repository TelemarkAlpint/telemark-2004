<HTML>
  <HEAD>
	 <TITLE>NTNUI Telemark</TITLE>
	 <LINK REL="stylesheet" HREF="../style.css" TYPE="text/css">
  </HEAD>
  <BODY>

  <form method="POST" action="ny.php">
  	<p><b>Navn:</b><br>
	  	<input type="text" name="navn" size="20"></p>
	<p><b>E-post:</b><br>
		<input type="text" name="epost" size="20"></p>
	<p><b>Annet:</b><br>
	  	<input type="text" name="annet" size="20"></p>
	<p><b>Passord*:</b> (f.eks f�dselsdato)<br>
	  	<input type="password" name="passord" size="20"></p>
  	<p><input type="submit" value="Meld p�" name="B1"></p>
  </form>
<?php
class Input {
	var $allLines;
	var $alleNavn;
	var $alleEpost;
	var $alleAnnet;
	var $allePassord;
	var $numberOfLines;
	function Input($inData){
		$this->allLines = $inData;
		$this->numberOfLines = count($inData)-1;
		#print "antall linjer: $this->numberOfLines<br>\n<br>\n";
		for($i = 0; $i < $this->numberOfLines; $i++){
			#print "linje$i: $inData[$i]<br>\n";
			$linje = split("#", $inData[$i]);
			$this->alleNavn[] = $linje[0];
			$this->alleEpost[] = $linje[1];
			$this->alleAnnet[] = $linje[2];
			$this->allePassord[] = $linje[3];
		}
		return;
	}
	#skriver ut alle p�meldte persjoner
	function skrivUt(){
		for($i = 0; $i < $this->numberOfLines; $i++){
			$tall = $i+1;
			echo '<tr><td>', $tall, '</td><td>', $this->alleNavn[$i], '</td><td>', $this->alleEpost[$i], '</td><td>', $this->alleAnnet[$i], "</td></tr>\n";
		}
		return;
	}
	
	#sjekker om navnet finnes fra f�r
	function finnes($sokeNavn){
		$sokeNavn = strtolower($sokeNavn);
		$found = false;
		$i = 0;
		$end = $this->numberOfLines;
		echo "<hr>";
		while ((!$found) && ($i < $end)){
			echo strtolower($this->alleNavn[$i]);
			echo " - ";
			echo $sokeNavn;
			if (strstr(strtolower($this->alleNavn[$i]), $sokeNavn)){
			#if (strtolower($this->alleNavn[$i])==$sokeNavn){
				echo " *";
				#$found = true;
			}
			$i++;
			echo "<br>";
		}
		echo "<hr>";
		if (!$found) $i = -1;
		return $i;
	}
}

#definerer variable
	$navn;
	global $epost;
	global $annet;
	global $passord;
	$linjeskift = chr(13);
	global $filename;
	$filename = "data.txt";
	
#leser inn fra fila
	$fp = fopen($filename, "r");
	$gammelData = fread($fp, filesize($filename));
	fclose($fp);

#oppretter inputklasse
	$linjer = split(".:::.$linjeskift", $gammelData);
	$pameldte = new Input($linjer);
?>
<hr>
<p><b>Hittil p�meldte</b></p>
<table border=0.1 cellpadding=0 bordercolor=#524545 cellspacing=0 width=100%>
  <tr>
    <td width><b>Nr</b></td>
    <td width><b>Navn</b></td>
    <td width><b>E-post</b></td>
    <td width><b>Annet</b></td>
  </tr>
<?php
	$pameldte->skrivUt();
?>
</table>
<?php
	$pameldte->finnes($navn);
?>
</body>
</html>